
	mapboxgl.accessToken ="pk.eyJ1IjoibWFoZXNoLTA5IiwiYSI6ImNtYWY5OWxzcTAwOWUybXF3dzR5djB5eXAifQ.BuI-Okk08XWnydgEb2UhVA";
    const map = new mapboxgl.Map({
        container: 'map', // container ID
        style: "mapbox://styles/mapbox/streets-v12",
        center: [77.2090, 28.6139], // starting position [lng, lat]. Note that lat must be set between -90 and 90
        zoom: 9 // starting zoom
    });
